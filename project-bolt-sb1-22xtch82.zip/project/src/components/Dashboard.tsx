import React from 'react';
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  AlertTriangle,
  TrendingUp,
  HardDrive,
  Shield,
  Activity
} from 'lucide-react';
import { StatCard } from './StatCard';
import { BackupStatusChart } from './BackupStatusChart';
import { RecentActivity } from './RecentActivity';

export function Dashboard() {
  const stats = [
    {
      title: 'Successful Backups',
      value: '247',
      change: '+12 today',
      changeType: 'positive' as const,
      icon: CheckCircle,
      color: 'green'
    },
    {
      title: 'Failed Backups',
      value: '3',
      change: '-2 from yesterday',
      changeType: 'positive' as const,
      icon: XCircle,
      color: 'red'
    },
    {
      title: 'Pending Jobs',
      value: '8',
      change: 'Next in 2h 15m',
      changeType: 'neutral' as const,
      icon: Clock,
      color: 'blue'
    },
    {
      title: 'Storage Used',
      value: '1.2TB',
      change: '+45GB this week',
      changeType: 'neutral' as const,
      icon: HardDrive,
      color: 'purple'
    }
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Backup Dashboard</h1>
          <p className="text-gray-600 mt-1">Monitor and manage your automated backup operations</p>
        </div>
        <div className="flex items-center gap-2 bg-green-50 text-green-700 px-4 py-2 rounded-lg">
          <Shield className="w-4 h-4" />
          <span className="font-medium">All Systems Operational</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <BackupStatusChart />
        </div>
        <div>
          <RecentActivity />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Active Backup Jobs</h3>
          <Activity className="w-5 h-5 text-gray-400" />
        </div>
        
        <div className="space-y-4">
          {[
            { name: 'Marketing Shared Drive', progress: 85, status: 'running', eta: '15 min' },
            { name: 'Finance Documents', progress: 100, status: 'completed', eta: 'Done' },
            { name: 'Development Code', progress: 32, status: 'running', eta: '45 min' },
            { name: 'HR Personnel Files', progress: 0, status: 'queued', eta: '2h 15m' }
          ].map((job, index) => (
            <div key={index} className="p-4 border border-gray-100 rounded-lg hover:border-gray-200 transition-colors">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-gray-900">{job.name}</span>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  job.status === 'completed' ? 'bg-green-100 text-green-700' :
                  job.status === 'running' ? 'bg-blue-100 text-blue-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {job.status}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      job.status === 'completed' ? 'bg-green-500' :
                      job.status === 'running' ? 'bg-blue-500' :
                      'bg-gray-300'
                    }`}
                    style={{ width: `${job.progress}%` }}
                  ></div>
                </div>
                <span className="text-sm text-gray-600 min-w-[60px]">{job.progress}%</span>
                <span className="text-sm text-gray-500 min-w-[60px]">ETA: {job.eta}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}