import React from 'react';
import { CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';

export function RecentActivity() {
  const activities = [
    {
      type: 'success',
      title: 'Marketing Drive Backup',
      description: 'Completed successfully',
      time: '2 minutes ago',
      icon: CheckCircle
    },
    {
      type: 'error',
      title: 'Finance Backup Failed',
      description: 'Network timeout error',
      time: '15 minutes ago',
      icon: XCircle
    },
    {
      type: 'warning',
      title: 'Low Storage Warning',
      description: 'Backup drive 85% full',
      time: '1 hour ago',
      icon: AlertTriangle
    },
    {
      type: 'info',
      title: 'Scheduled Backup',
      description: 'HR files queued for backup',
      time: '2 hours ago',
      icon: Clock
    },
    {
      type: 'success',
      title: 'Development Backup',
      description: 'Completed with 0 errors',
      time: '3 hours ago',
      icon: CheckCircle
    }
  ];

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'text-green-600 bg-green-50';
      case 'error':
        return 'text-red-600 bg-red-50';
      case 'warning':
        return 'text-amber-600 bg-amber-50';
      default:
        return 'text-blue-600 bg-blue-50';
    }
  };

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Recent Activity</h3>
      
      <div className="space-y-4">
        {activities.map((activity, index) => {
          const Icon = activity.icon;
          return (
            <div key={index} className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
              <div className={`p-2 rounded-lg ${getActivityColor(activity.type)}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-gray-900 text-sm">{activity.title}</h4>
                <p className="text-gray-600 text-sm">{activity.description}</p>
                <p className="text-gray-400 text-xs mt-1">{activity.time}</p>
              </div>
            </div>
          );
        })}
      </div>
      
      <button className="w-full mt-4 pt-4 border-t border-gray-100 text-sm text-blue-600 hover:text-blue-700 font-medium transition-colors">
        View All Activity
      </button>
    </div>
  );
}