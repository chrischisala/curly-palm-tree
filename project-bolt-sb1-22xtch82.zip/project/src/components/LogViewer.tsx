import React, { useState } from 'react';
import { Search, Filter, Download, RefreshCw } from 'lucide-react';

export function LogViewer() {
  const [searchTerm, setSearchTerm] = useState('');
  const [logLevel, setLogLevel] = useState('all');

  const logs = [
    {
      timestamp: '2024-01-15 14:32:15',
      level: 'info',
      job: 'Marketing Drive Backup',
      message: 'Backup completed successfully. 1,247 files processed.',
      details: 'Duration: 8m 32s | Size: 2.3GB'
    },
    {
      timestamp: '2024-01-15 14:25:43',
      level: 'warning',
      job: 'Finance Backup',
      message: 'Some files were skipped due to permissions.',
      details: '3 files skipped | /finance/restricted/'
    },
    {
      timestamp: '2024-01-15 14:15:22',
      level: 'error',
      job: 'Development Backup',
      message: 'Backup failed: Network timeout',
      details: 'Error: Connection timeout after 30 seconds'
    },
    {
      timestamp: '2024-01-15 14:10:11',
      level: 'info',
      job: 'HR Files Backup',
      message: 'Starting scheduled backup...',
      details: 'Source: /shared/hr | Destination: /backup/hr'
    },
    {
      timestamp: '2024-01-15 14:05:33',
      level: 'success',
      job: 'Marketing Drive Backup',
      message: 'Backup job queued successfully',
      details: 'Next run: 2024-01-16 02:00:00'
    }
  ];

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'success':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'error':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'warning':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default:
        return 'bg-blue-100 text-blue-700 border-blue-200';
    }
  };

  const filteredLogs = logs.filter(log => {
    const matchesSearch = log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.job.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLevel = logLevel === 'all' || log.level === logLevel;
    return matchesSearch && matchesLevel;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Backup Logs</h1>
          <p className="text-gray-600 mt-1">Monitor backup operations and troubleshoot issues</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <Download className="w-4 h-4" />
            Export Logs
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
            <select
              value={logLevel}
              onChange={(e) => setLogLevel(e.target.value)}
              className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none bg-white"
            >
              <option value="all">All Levels</option>
              <option value="success">Success</option>
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="error">Error</option>
            </select>
          </div>
        </div>

        <div className="space-y-3">
          {filteredLogs.map((log, index) => (
            <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`px-2 py-1 text-xs font-medium rounded border ${getLevelColor(log.level)}`}>
                      {log.level.toUpperCase()}
                    </span>
                    <span className="text-sm font-medium text-gray-900">{log.job}</span>
                    <span className="text-sm text-gray-500">{log.timestamp}</span>
                  </div>
                  <p className="text-gray-700 mb-1">{log.message}</p>
                  {log.details && (
                    <p className="text-sm text-gray-500">{log.details}</p>
                  )}
                </div>
              </div>
            </div>
          ))}
          
          {filteredLogs.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <p>No logs found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}