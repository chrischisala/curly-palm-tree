import React, { useState } from 'react';
import { Plus, Edit, Trash2, Play, Pause, Settings } from 'lucide-react';
import { CreateJobModal } from './CreateJobModal';

export function BackupJobs() {
  const [showCreateModal, setShowCreateModal] = useState(false);

  const jobs = [
    {
      id: 1,
      name: 'Marketing Shared Drive',
      source: '/shared/marketing',
      destination: '/backup/marketing',
      schedule: 'Daily at 2:00 AM',
      status: 'active',
      lastRun: '2024-01-15 02:00:15',
      lastStatus: 'success',
      nextRun: '2024-01-16 02:00:00'
    },
    {
      id: 2,
      name: 'Finance Documents',
      source: '/shared/finance',
      destination: '/backup/finance',
      schedule: 'Daily at 3:00 AM',
      status: 'active',
      lastRun: '2024-01-15 03:00:22',
      lastStatus: 'success',
      nextRun: '2024-01-16 03:00:00'
    },
    {
      id: 3,
      name: 'Development Code Repository',
      source: '/shared/dev',
      destination: '/backup/dev',
      schedule: 'Every 6 hours',
      status: 'paused',
      lastRun: '2024-01-14 18:00:45',
      lastStatus: 'failed',
      nextRun: 'Paused'
    },
    {
      id: 4,
      name: 'HR Personnel Files',
      source: '/shared/hr',
      destination: '/backup/hr',
      schedule: 'Weekly on Sunday',
      status: 'active',
      lastRun: '2024-01-14 01:00:12',
      lastStatus: 'success',
      nextRun: '2024-01-21 01:00:00'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'paused':
        return 'bg-yellow-100 text-yellow-700';
      case 'failed':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getLastStatusColor = (status: string) => {
    switch (status) {
      case 'success':
        return 'text-green-600';
      case 'failed':
        return 'text-red-600';
      case 'warning':
        return 'text-yellow-600';
      default:
        return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Backup Jobs</h1>
          <p className="text-gray-600 mt-1">Configure and manage automated backup schedules</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Create New Job
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Job Name</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Source</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Schedule</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Status</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Last Run</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Next Run</th>
                <th className="text-left py-4 px-6 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr key={job.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-6">
                    <div>
                      <div className="font-medium text-gray-900">{job.name}</div>
                      <div className="text-sm text-gray-500">{job.destination}</div>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <code className="text-sm bg-gray-100 px-2 py-1 rounded">{job.source}</code>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-600">{job.schedule}</td>
                  <td className="py-4 px-6">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(job.status)}`}>
                      {job.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm">
                      <div className="text-gray-900">{job.lastRun}</div>
                      <div className={`${getLastStatusColor(job.lastStatus)} font-medium`}>
                        {job.lastStatus}
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-sm text-gray-600">{job.nextRun}</td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      {job.status === 'active' ? (
                        <button className="p-1 text-gray-400 hover:text-yellow-600 transition-colors" title="Pause">
                          <Pause className="w-4 h-4" />
                        </button>
                      ) : (
                        <button className="p-1 text-gray-400 hover:text-green-600 transition-colors" title="Resume">
                          <Play className="w-4 h-4" />
                        </button>
                      )}
                      <button className="p-1 text-gray-400 hover:text-blue-600 transition-colors" title="Configure">
                        <Settings className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-gray-400 hover:text-blue-600 transition-colors" title="Edit">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-gray-400 hover:text-red-600 transition-colors" title="Delete">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <CreateJobModal 
        isOpen={showCreateModal} 
        onClose={() => setShowCreateModal(false)} 
      />
    </div>
  );
}