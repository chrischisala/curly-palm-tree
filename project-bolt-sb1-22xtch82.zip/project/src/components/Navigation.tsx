import React from 'react';
import { View } from '../App';
import { 
  LayoutDashboard, 
  FolderSync, 
  FileText, 
  Settings as SettingsIcon,
  HardDrive
} from 'lucide-react';

interface NavigationProps {
  currentView: View;
  onViewChange: (view: View) => void;
}

export function Navigation({ currentView, onViewChange }: NavigationProps) {
  const navItems = [
    { id: 'dashboard' as View, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'jobs' as View, label: 'Backup Jobs', icon: FolderSync },
    { id: 'logs' as View, label: 'Logs', icon: FileText },
    { id: 'settings' as View, label: 'Settings', icon: SettingsIcon },
  ];

  return (
    <nav className="fixed left-0 top-0 h-full w-64 bg-slate-900 text-white p-6">
      <div className="flex items-center gap-3 mb-8 pb-6 border-b border-slate-700">
        <div className="p-2 bg-blue-600 rounded-lg">
          <HardDrive className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-xl font-bold">BackupManager</h1>
          <p className="text-slate-400 text-sm">Pro Edition</p>
        </div>
      </div>
      
      <ul className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          
          return (
            <li key={item.id}>
              <button
                onClick={() => onViewChange(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            </li>
          );
        })}
      </ul>
      
      <div className="absolute bottom-6 left-6 right-6">
        <div className="bg-slate-800 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">System Status</span>
          </div>
          <p className="text-xs text-slate-400">All services running</p>
        </div>
      </div>
    </nav>
  );
}