import React from 'react';
import { BarChart3 } from 'lucide-react';

export function BackupStatusChart() {
  const data = [
    { day: 'Mon', successful: 35, failed: 2 },
    { day: 'Tue', successful: 42, failed: 1 },
    { day: 'Wed', successful: 38, failed: 3 },
    { day: 'Thu', successful: 45, failed: 0 },
    { day: 'Fri', successful: 41, failed: 2 },
    { day: 'Sat', successful: 28, failed: 1 },
    { day: 'Sun', successful: 33, failed: 1 }
  ];

  const maxValue = Math.max(...data.map(d => d.successful + d.failed));

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Weekly Backup Performance</h3>
        <BarChart3 className="w-5 h-5 text-gray-400" />
      </div>
      
      <div className="flex items-end justify-between h-64 gap-4">
        {data.map((item, index) => {
          const successHeight = (item.successful / maxValue) * 200;
          const failHeight = (item.failed / maxValue) * 200;
          
          return (
            <div key={index} className="flex flex-col items-center flex-1">
              <div className="w-full flex flex-col items-center gap-1 mb-3">
                <div 
                  className="w-full bg-red-500 rounded-t transition-all duration-300 hover:bg-red-600"
                  style={{ height: `${failHeight}px` }}
                  title={`${item.failed} failed`}
                ></div>
                <div 
                  className="w-full bg-green-500 rounded-b transition-all duration-300 hover:bg-green-600"
                  style={{ height: `${successHeight}px` }}
                  title={`${item.successful} successful`}
                ></div>
              </div>
              <span className="text-sm font-medium text-gray-600">{item.day}</span>
            </div>
          );
        })}
      </div>
      
      <div className="flex items-center justify-center gap-6 mt-6 pt-4 border-t border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded"></div>
          <span className="text-sm text-gray-600">Successful</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded"></div>
          <span className="text-sm text-gray-600">Failed</span>
        </div>
      </div>
    </div>
  );
}