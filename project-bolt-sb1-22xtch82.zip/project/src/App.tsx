import React, { useState } from 'react';
import { Dashboard } from './components/Dashboard';
import { BackupJobs } from './components/BackupJobs';
import { LogViewer } from './components/LogViewer';
import { Settings } from './components/Settings';
import { Navigation } from './components/Navigation';

export type View = 'dashboard' | 'jobs' | 'logs' | 'settings';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard />;
      case 'jobs':
        return <BackupJobs />;
      case 'logs':
        return <LogViewer />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation currentView={currentView} onViewChange={setCurrentView} />
      <main className="ml-64 p-8">
        {renderView()}
      </main>
    </div>
  );
}

export default App;